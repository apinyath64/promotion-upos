<script setup>
import { ref, computed } from 'vue';
import { 
  Check, XSquare, Search, Filter, MoreHorizontal, Edit, Shield, UserCheck, Trash2, ToggleRight, ToggleLeft
} from 'lucide-vue-next';
import Badge from '../components/ui/Badge.vue';
import Modal from '../components/ui/Modal.vue';
import { useApp } from '../composables/useApp';
import { renderIcon } from '../utils/iconUtils';

const { 
  branches, userRole, setCurrentView, 
  setManagingBranch, addLog, permissions 
} = useApp();

const searchTerm = ref('');
const filterType = ref('All');
const selectedBranchIds = ref([]);
const activeMenuId = ref(null);

// Modal states
const isBranchModalOpen = ref(false);
const editingBranch = ref(null);
const isManagePermModalOpen = ref(false);
const managingBranchPerm = ref(null);
const tempBranchPerms = ref([]);
const isBulkModalOpen = ref(false);
const bulkActionType = ref(null);
const selectedBulkPermissions = ref([]);
const deleteModal = ref({ isOpen: false, id: null, title: '', message: '' });

const filteredBranches = computed(() => {
  return branches.value.filter(b => 
    b.name.toLowerCase().includes(searchTerm.value.toLowerCase()) && 
    (filterType.value === 'All' || b.type === filterType.value)
  );
});

const toggleBranchSelection = (id) => {
  if (selectedBranchIds.value.includes(id)) {
    selectedBranchIds.value = selectedBranchIds.value.filter(bid => bid !== id);
  } else {
    selectedBranchIds.value.push(id);
  }
};

const selectAllBranches = (e) => {
  selectedBranchIds.value = e.target.checked ? filteredBranches.value.map(b => b.id) : [];
};

const toggleBranchStatus = (id) => {
  if (userRole.value === 'Branch Admin') return;
  const branch = branches.value.find(b => b.id === id);
  if (branch) {
    branch.status = branch.status === 'Active' ? 'Inactive' : 'Active';
  }
};

const handleSaveBranch = (e) => {
  const formData = new FormData(e.target);
  const updatedBranch = {
    ...editingBranch.value,
    name: formData.get('name'),
    type: formData.get('type'),
    status: formData.get('status')
  };
  
  const index = branches.value.findIndex(b => b.id === editingBranch.value.id);
  if (index !== -1) {
    branches.value[index] = updatedBranch;
  }
  
  addLog('Branch Update', `Updated branch: ${updatedBranch.name}`);
  isBranchModalOpen.value = false;
  editingBranch.value = null;
};

const handleManageInternals = (branch) => {
  setManagingBranch(branch);
  setCurrentView('b_config');
  activeMenuId.value = null;
};

const openManagePermModal = (branch) => {
  managingBranchPerm.value = branch;
  tempBranchPerms.value = [...branch.permissions];
  isManagePermModalOpen.value = true;
  activeMenuId.value = null;
};

const handleTogglePermission = (permId) => {
  if (tempBranchPerms.value.includes(permId)) {
    tempBranchPerms.value = tempBranchPerms.value.filter(id => id !== permId);
  } else {
    tempBranchPerms.value.push(permId);
  }
};

const saveBranchPermissions = () => {
  const branch = branches.value.find(b => b.id === managingBranchPerm.value.id);
  if (branch) {
    branch.permissions = tempBranchPerms.value;
  }
  addLog('Permission Update', `Updated individual permissions for ${managingBranchPerm.value.name}`);
  isManagePermModalOpen.value = false;
  managingBranchPerm.value = null;
};

const handleBulkActionClick = (type) => {
  if (selectedBranchIds.value.length === 0) return;
  bulkActionType.value = type;
  selectedBulkPermissions.value = [];
  isBulkModalOpen.value = true;
};

const executeBulkAction = () => {
  branches.value.forEach(branch => {
    if (!selectedBranchIds.value.includes(branch.id) || branch.status === 'Inactive') return;
    
    let newPerms = [...branch.permissions];
    if (bulkActionType.value === 'Enable') {
      selectedBulkPermissions.value.forEach(pId => { 
        if (!newPerms.includes(pId)) newPerms.push(pId); 
      });
    } else {
      newPerms = newPerms.filter(pId => !selectedBulkPermissions.value.includes(pId));
    }
    branch.permissions = newPerms;
  });
  
  isBulkModalOpen.value = false;
  selectedBranchIds.value = [];
  addLog('Bulk Action', `${bulkActionType.value} permissions for selected branches`);
};

const promptDelete = (id, title, message) => {
  deleteModal.value = { isOpen: true, id, title, message };
  activeMenuId.value = null;
};

const confirmDelete = () => {
  const index = branches.value.findIndex(b => b.id === deleteModal.value.id);
  if (index !== -1) {
    branches.value.splice(index, 1);
  }
  deleteModal.value.isOpen = false;
};
</script>

<template>
  <div class="space-y-6">
    <div class="flex items-center justify-between">
      <h2 class="text-2xl font-bold text-gray-800">Branch Management</h2>
      <div class="flex gap-2">
        <template v-if="selectedBranchIds.length > 0">
          <button @click="handleBulkActionClick('Enable')" class="px-4 py-2 bg-green-500 text-white rounded-lg text-sm font-medium hover:bg-green-600 transition-colors flex items-center gap-2">
            <Check :size="16" /> Enable Permissions
          </button>
          <button @click="handleBulkActionClick('Disable')" class="px-4 py-2 bg-red-500 text-white rounded-lg text-sm font-medium hover:bg-red-600 transition-colors flex items-center gap-2">
            <XSquare :size="16" /> Disable Permissions
          </button>
        </template>
      </div>
    </div>

    <div class="flex gap-4">
      <div class="relative flex-1">
        <Search class="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" :size="18" />
        <input 
          v-model="searchTerm"
          placeholder="ค้นหาสาขา..." 
          class="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500" 
        />
      </div>
      <div class="relative">
        <Filter class="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" :size="18" />
        <select 
          v-model="filterType"
          class="pl-10 pr-8 py-2.5 border border-gray-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 appearance-none bg-white cursor-pointer"
        >
          <option value="All">ทุกประเภท</option>
          <option value="Hospital">Hospital</option>
          <option value="Factory">Factory</option>
          <option value="School">School</option>
          <option value="Canteen">Canteen</option>
        </select>
      </div>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <table class="w-full">
        <thead class="bg-gray-50 border-b border-gray-100">
          <tr>
            <th class="px-4 py-3 text-left">
              <input 
                type="checkbox" 
                @change="selectAllBranches"
                class="rounded" 
              />
            </th>
            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Branch</th>
            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Type</th>
            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Status</th>
            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Permissions</th>
            <th class="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">Actions</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-50">
          <tr v-for="branch in filteredBranches" :key="branch.id" class="hover:bg-gray-50/50 transition-colors">
            <td class="px-4 py-3">
              <input 
                type="checkbox" 
                :checked="selectedBranchIds.includes(branch.id)"
                @change="toggleBranchSelection(branch.id)"
                class="rounded" 
              />
            </td>
            <td class="px-4 py-3">
              <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white font-bold">
                  {{ branch.name.charAt(0) }}
                </div>
                <div>
                  <p class="font-medium text-gray-800">{{ branch.name }}</p>
                  <p class="text-xs text-gray-400">{{ branch.id }}</p>
                </div>
              </div>
            </td>
            <td class="px-4 py-3"><Badge :type="branch.type">{{ branch.type }}</Badge></td>
            <td class="px-4 py-3">
              <button @click="toggleBranchStatus(branch.id)" :disabled="userRole === 'Branch Admin'" class="flex items-center gap-2 cursor-pointer disabled:cursor-not-allowed">
                <ToggleRight v-if="branch.status === 'Active'" class="text-green-500" :size="24" />
                <ToggleLeft v-else class="text-gray-400" :size="24" />
                <Badge :type="branch.status">{{ branch.status }}</Badge>
              </button>
            </td>
            <td class="px-4 py-3">
              <div class="flex flex-wrap gap-1">
                <template v-if="branch.permissions.length > 0">
                  <span 
                    v-for="pId in branch.permissions.slice(0, 2)" 
                    :key="pId"
                    class="px-2 py-0.5 bg-indigo-50 text-indigo-700 rounded text-xs"
                  >
                    {{ permissions.find(x => x.id === pId)?.name.split(' ')[0] }}
                  </span>
                  <span v-if="branch.permissions.length > 2" class="px-2 py-0.5 bg-gray-100 text-gray-600 rounded text-xs">
                    +{{ branch.permissions.length - 2 }}
                  </span>
                </template>
                <span v-else class="text-gray-400 text-sm">No permissions</span>
              </div>
            </td>
            <td class="px-4 py-3 text-right relative">
              <button @click="activeMenuId = activeMenuId === branch.id ? null : branch.id" class="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <MoreHorizontal :size="18" />
              </button>
              <div v-if="activeMenuId === branch.id" class="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-100 z-10 py-1">
                <button @click="editingBranch = branch; isBranchModalOpen = true; activeMenuId = null" class="w-full px-4 py-2 text-left text-sm hover:bg-gray-50 flex items-center gap-2">
                  <Edit :size="14" /> Edit Details
                </button>
                <button @click="openManagePermModal(branch)" class="w-full px-4 py-2 text-left text-sm hover:bg-gray-50 flex items-center gap-2">
                  <Shield :size="14" /> Manage Permissions
                </button>
                <button @click="handleManageInternals(branch)" class="w-full px-4 py-2 text-left text-sm hover:bg-gray-50 flex items-center gap-2">
                  <UserCheck :size="14" /> Manage Internals
                </button>
                <hr class="my-1" />
                <button @click="promptDelete(branch.id, 'Delete Branch', `Are you sure you want to delete &quot;${branch.name}&quot;?`)" class="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50 flex items-center gap-2">
                  <Trash2 :size="14" /> Delete
                </button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Edit Branch Modal -->
    <Modal :is-open="isBranchModalOpen" @close="isBranchModalOpen = false" title="Edit Branch">
      <form id="branchForm" @submit.prevent="handleSaveBranch" class="space-y-4">
        <div><label class="text-xs font-bold text-gray-500 uppercase">Branch Name</label><input name="name" :value="editingBranch?.name" required class="w-full mt-1 p-2.5 border border-gray-200 rounded-lg text-sm" /></div>
        <div>
          <label class="text-xs font-bold text-gray-500 uppercase">Type</label>
          <select name="type" :value="editingBranch?.type" class="w-full mt-1 p-2.5 border border-gray-200 rounded-lg text-sm">
            <option value="Hospital">Hospital</option>
            <option value="Factory">Factory</option>
            <option value="School">School</option>
            <option value="Canteen">Canteen</option>
          </select>
        </div>
        <div>
          <label class="text-xs font-bold text-gray-500 uppercase">Status</label>
          <select name="status" :value="editingBranch?.status" class="w-full mt-1 p-2.5 border border-gray-200 rounded-lg text-sm">
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
        </div>
      </form>
      <template #footer>
        <button type="button" @click="isBranchModalOpen = false" class="px-4 py-2 border border-gray-200 rounded-lg text-sm hover:bg-gray-50">Cancel</button>
        <button type="submit" form="branchForm" class="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-700">Save</button>
      </template>
    </Modal>

    <!-- Manage Permissions Modal -->
    <Modal :is-open="isManagePermModalOpen" @close="isManagePermModalOpen = false" :title="`Manage Permissions: ${managingBranchPerm?.name}`">
      <div class="space-y-3">
        <div v-for="perm in permissions" :key="perm.id" class="flex items-center justify-between p-3 border border-gray-100 rounded-lg">
          <div class="flex items-center gap-3">
            <div 
              class="w-8 h-8 rounded-lg flex items-center justify-center"
              :class="tempBranchPerms.includes(perm.id) ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-400'"
            >
              <component :is="renderIcon(perm.icon, 16)" />
            </div>
            <span class="font-medium text-sm">{{ perm.name }}</span>
          </div>
          <button @click="handleTogglePermission(perm.id)">
            <ToggleRight v-if="tempBranchPerms.includes(perm.id)" class="text-blue-500" :size="28" />
            <ToggleLeft v-else class="text-gray-400" :size="28" />
          </button>
        </div>
      </div>
      <template #footer>
        <button @click="isManagePermModalOpen = false" class="px-4 py-2 border border-gray-200 rounded-lg text-sm hover:bg-gray-50">Cancel</button>
        <button @click="saveBranchPermissions" class="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-700">Save</button>
      </template>
    </Modal>

    <!-- Bulk Action Modal -->
    <Modal :is-open="isBulkModalOpen" @close="isBulkModalOpen = false" :title="`Bulk ${bulkActionType} Permissions`">
      <p class="text-sm text-gray-600 mb-4">Select permissions to {{ bulkActionType?.toLowerCase() }}:</p>
      <div class="space-y-2">
        <label v-for="perm in permissions" :key="perm.id" class="flex items-center gap-3 p-3 border border-gray-100 rounded-lg cursor-pointer hover:bg-gray-50">
          <input 
            type="checkbox" 
            :checked="selectedBulkPermissions.includes(perm.id)" 
            @change="selectedBulkPermissions.includes(perm.id) ? selectedBulkPermissions = selectedBulkPermissions.filter(id => id !== perm.id) : selectedBulkPermissions.push(perm.id)"
            class="rounded" 
          />
          <span class="text-sm">{{ perm.name }}</span>
        </label>
      </div>
      <template #footer>
        <button @click="isBulkModalOpen = false" class="px-4 py-2 border border-gray-200 rounded-lg text-sm hover:bg-gray-50">Cancel</button>
        <button @click="executeBulkAction" :disabled="selectedBulkPermissions.length === 0" class="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-700 disabled:opacity-50">Apply to {{ selectedBranchIds.length }} Branches</button>
      </template>
    </Modal>

    <!-- Delete Confirmation Modal -->
    <Modal :is-open="deleteModal.isOpen" @close="deleteModal.isOpen = false" :title="deleteModal.title">
      <p class="text-gray-600">{{ deleteModal.message }}</p>
      <template #footer>
        <button @click="deleteModal.isOpen = false" class="px-4 py-2 border border-gray-200 rounded-lg text-sm hover:bg-gray-50">Cancel</button>
        <button @click="confirmDelete" class="px-4 py-2 bg-red-600 text-white rounded-lg text-sm hover:bg-red-700">Delete</button>
      </template>
    </Modal>
  </div>
</template>
