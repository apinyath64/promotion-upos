<script setup>
import Badge from '../components/ui/Badge.vue';
import { useApp } from '../composables/useApp';

const { logs } = useApp();
</script>

<template>
  <div class="space-y-6">
    <h2 class="text-2xl font-bold text-gray-800">Audit Logs</h2>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <table class="w-full">
        <thead class="bg-gray-50 border-b border-gray-100">
          <tr>
            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Timestamp</th>
            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Admin</th>
            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Action</th>
            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Details</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-50">
          <tr v-for="log in logs" :key="log.id" class="hover:bg-gray-50/50">
            <td class="px-4 py-3 text-sm text-gray-500">{{ log.timestamp }}</td>
            <td class="px-4 py-3 text-sm font-medium">{{ log.admin }}</td>
            <td class="px-4 py-3"><Badge type="default">{{ log.action }}</Badge></td>
            <td class="px-4 py-3 text-sm text-gray-600">{{ log.details }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>
