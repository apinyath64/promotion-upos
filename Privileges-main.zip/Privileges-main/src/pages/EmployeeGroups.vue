<script setup>
import { ref, computed } from 'vue';
import { Plus, Edit, Trash2 } from 'lucide-vue-next';
import Modal from '../components/ui/Modal.vue';
import { useApp } from '../composables/useApp';

const { 
  branchGroups, permissions, getActiveBranchPerms, addLog 
} = useApp();

const activeBranchPermIds = computed(() => getActiveBranchPerms());

const isGroupModalOpen = ref(false);
const editingGroup = ref(null);
const deleteModal = ref({ isOpen: false, id: null, title: '', message: '' });

const handleSaveGroup = (e) => {
  const formData = new FormData(e.target);
  
  const rules = activeBranchPermIds.value.map(pid => {
    if (formData.get(`perm_${pid}`)) {
      return { 
        permId: pid, 
        validFrom: formData.get(`date_from_${pid}`), 
        validTo: formData.get(`date_to_${pid}`) 
      };
    }
    return null;
  }).filter(Boolean);

  const newGroup = { 
    id: editingGroup.value ? editingGroup.value.id : `G${Date.now()}`, 
    name: formData.get('groupName'), 
    rules 
  };

  if (editingGroup.value) {
    const index = branchGroups.value.findIndex(g => g.id === editingGroup.value.id);
    if (index !== -1) branchGroups.value[index] = newGroup;
    addLog('Group Update', `Updated group: ${newGroup.name}`);
  } else {
    branchGroups.value.push(newGroup);
    addLog('Group Create', `Created group: ${newGroup.name}`);
  }
  
  isGroupModalOpen.value = false;
  editingGroup.value = null;
};

const openModal = (group) => {
  editingGroup.value = group;
  isGroupModalOpen.value = true;
};

const promptDelete = (id, title, message) => {
  deleteModal.value = { isOpen: true, id, title, message };
};

const confirmDelete = () => {
  const index = branchGroups.value.findIndex(g => g.id === deleteModal.value.id);
  if (index !== -1) {
    branchGroups.value.splice(index, 1);
    addLog('Group Delete', `Deleted group ID: ${deleteModal.value.id}`);
  }
  deleteModal.value.isOpen = false;
};

const getRuleForPerm = (rules, permId) => {
  return rules?.find(r => r.permId === permId);
};
</script>

<template>
  <div class="space-y-6">
    <div class="flex items-center justify-between">
      <h2 class="text-2xl font-bold text-gray-800">Employee Groups</h2>
      <button @click="openModal(null)" class="px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm font-medium hover:bg-emerald-700 transition-colors flex items-center gap-2">
        <Plus :size="16" /> Create Group
      </button>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div v-for="group in branchGroups" :key="group.id" class="bg-white rounded-xl p-5 border border-gray-100 shadow-sm">
        <div class="flex items-center justify-between">
          <h3 class="font-semibold text-gray-800">{{ group.name }}</h3>
          <div class="flex gap-2">
            <button @click="openModal(group)" class="p-2 hover:bg-gray-100 rounded-lg">
              <Edit :size="16" />
            </button>
            <button @click="promptDelete(group.id, 'Delete Group', `Are you sure you want to delete &quot;${group.name}&quot;?`)" class="p-2 hover:bg-red-50 text-red-600 rounded-lg">
              <Trash2 :size="16" />
            </button>
          </div>
        </div>
        <div class="mt-3">
          <p class="text-xs text-gray-400 mb-2">Assigned Wallets:</p>
          <div class="flex flex-wrap gap-1">
            <template v-for="r in group.rules" :key="r.permId">
              <span 
                v-if="permissions.find(x => x.id === r.permId)"
                class="px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded text-xs"
              >
                {{ permissions.find(x => x.id === r.permId).name.split(' ')[0] }}
              </span>
            </template>
          </div>
        </div>
      </div>
    </div>

    <!-- Group Modal -->
    <Modal :is-open="isGroupModalOpen" @close="isGroupModalOpen = false" :title="editingGroup ? 'Edit Group' : 'Create Group'" size="lg">
      <form id="groupForm" @submit.prevent="handleSaveGroup" class="space-y-4">
        <div><label class="text-xs font-bold text-gray-500 uppercase">Group Name</label><input name="groupName" :value="editingGroup?.name" required class="w-full mt-1 p-2.5 border border-gray-200 rounded-lg text-sm" /></div>
        <div>
          <label class="text-xs font-bold text-gray-500 uppercase mb-2 block">Assign Wallets</label>
          <div class="space-y-2">
            <template v-if="activeBranchPermIds.length > 0">
              <div v-for="pid in activeBranchPermIds" :key="pid" class="p-3 border border-gray-100 rounded-lg">
                <label class="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" :name="`perm_${pid}`" :checked="!!getRuleForPerm(editingGroup?.rules, pid)" class="rounded" />
                  <span class="text-sm font-medium">{{ permissions.find(p => p.id === pid)?.name }}</span>
                </label>
                <div class="flex gap-2 mt-2 ml-6">
                  <input type="date" :name="`date_from_${pid}`" :value="getRuleForPerm(editingGroup?.rules, pid)?.validFrom" placeholder="From" class="flex-1 p-2 border border-gray-200 rounded text-sm" />
                  <input type="date" :name="`date_to_${pid}`" :value="getRuleForPerm(editingGroup?.rules, pid)?.validTo" placeholder="To" class="flex-1 p-2 border border-gray-200 rounded text-sm" />
                </div>
              </div>
            </template>
            <p v-else class="text-gray-400 text-sm">No wallets available for this branch.</p>
          </div>
        </div>
      </form>
      <template #footer>
        <button type="button" @click="isGroupModalOpen = false" class="px-4 py-2 border border-gray-200 rounded-lg text-sm hover:bg-gray-50">Cancel</button>
        <button type="submit" form="groupForm" class="px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm hover:bg-emerald-700">Save</button>
      </template>
    </Modal>

    <!-- Delete Modal -->
    <Modal :is-open="deleteModal.isOpen" @close="deleteModal.isOpen = false" :title="deleteModal.title">
      <p class="text-gray-600">{{ deleteModal.message }}</p>
      <template #footer>
        <button @click="deleteModal.isOpen = false" class="px-4 py-2 border border-gray-200 rounded-lg text-sm hover:bg-gray-50">Cancel</button>
        <button @click="confirmDelete" class="px-4 py-2 bg-red-600 text-white rounded-lg text-sm hover:bg-red-700">Delete</button>
      </template>
    </Modal>
  </div>
</template>
