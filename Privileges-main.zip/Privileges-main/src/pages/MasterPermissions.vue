<script setup>
import { ref, computed } from 'vue';
import { 
  Plus, Edit, Trash2, Coffee, DollarSign, Settings
} from 'lucide-vue-next';
import Badge from '../components/ui/Badge.vue';
import Modal from '../components/ui/Modal.vue';
import { useApp } from '../composables/useApp';
import { renderIcon } from '../utils/iconUtils';
import { WEEK_DAYS } from '../data/mockData';

const { permissions, addLog } = useApp();

// Local state
const isPermModalOpen = ref(false);
const editingPerm = ref(null);
const deleteModal = ref({ isOpen: false, id: null, title: '', message: '' });

// Form state
const permFormType = ref('auto_reset');
const selectedFundTypes = ref([]);
const selectedFrequency = ref('Daily');
const recurringWeeks = ref({ 1: [], 2: [], 3: [], 4: [], 5: [] });

const openPermModal = (perm) => {
  editingPerm.value = perm;
  if (perm) {
    permFormType.value = perm.type || 'auto_reset';
    selectedFundTypes.value = perm.fundTypes || [];
    selectedFrequency.value = perm.frequency;
    recurringWeeks.value = perm.recurringRule?.weeks || { 1: [], 2: [], 3: [], 4: [], 5: [] };
  } else {
    permFormType.value = 'auto_reset';
    selectedFundTypes.value = ['Auto Reset'];
    selectedFrequency.value = 'Daily';
    recurringWeeks.value = { 1: [], 2: [], 3: [], 4: [], 5: [] };
  }
  isPermModalOpen.value = true;
};

const handleSavePermission = (e) => {
  const formData = new FormData(e.target);
  const newPerm = {
    id: editingPerm.value ? editingPerm.value.id : `P${Date.now()}`,
    name: formData.get('name'),
    type: permFormType.value,
    icon: editingPerm.value?.icon || (permFormType.value === 'auto_reset' ? 'Coffee' : 'DollarSign'),
    fundTypes: permFormType.value === 'auto_reset' ? ['Auto Reset'] : selectedFundTypes.value,
    value: permFormType.value === 'auto_reset' ? parseFloat(formData.get('value')) : 0,
    frequency: permFormType.value === 'auto_reset' ? selectedFrequency.value : 'No Reset',
    usageLimit: permFormType.value === 'auto_reset' ? parseInt(formData.get('usageLimit')) : null,
    recurringRule: selectedFrequency.value === 'Recurring' ? { type: 'WeekGrid', weeks: recurringWeeks.value } : null
  };

  if (editingPerm.value) {
    const index = permissions.value.findIndex(p => p.id === editingPerm.value.id);
    if (index !== -1) permissions.value[index] = newPerm;
    addLog('Master Update', `Updated permission: ${newPerm.name}`);
  } else {
    permissions.value.push(newPerm);
    addLog('Master Create', `Created permission: ${newPerm.name}`);
  }
  isPermModalOpen.value = false;
};

const handleFundTypeToggle = (typeId) => {
  if (selectedFundTypes.value.includes(typeId)) {
    selectedFundTypes.value = selectedFundTypes.value.filter(t => t !== typeId);
  } else {
    selectedFundTypes.value.push(typeId);
  }
};

const handleGridToggle = (weekNum, dayId) => {
  const currentWeeks = recurringWeeks.value;
  const currentDays = currentWeeks[weekNum] || [];
  if (currentDays.includes(dayId)) {
    currentWeeks[weekNum] = currentDays.filter(d => d !== dayId);
  } else {
    currentWeeks[weekNum] = [...currentDays, dayId];
  }
  recurringWeeks.value = { ...currentWeeks };
};

const promptDelete = (id, title, message) => {
  deleteModal.value = { isOpen: true, id, title, message };
};

const confirmDelete = () => {
  const index = permissions.value.findIndex(p => p.id === deleteModal.value.id);
  if (index !== -1) {
    permissions.value.splice(index, 1);
    addLog('Master Delete', `Deleted permission ID: ${deleteModal.value.id}`);
  }
  deleteModal.value.isOpen = false;
};
</script>

<template>
  <div class="space-y-6">
    <div class="flex items-center justify-between">
      <h2 class="text-2xl font-bold text-gray-800">Master Permissions</h2>
      <button @click="openPermModal(null)" class="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors flex items-center gap-2">
        <Plus :size="16" /> Create Permission
      </button>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      <div v-for="perm in permissions" :key="perm.id" class="bg-white rounded-xl p-5 border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
        <div class="flex items-start justify-between">
          <div class="flex items-center gap-3">
            <div 
              class="w-12 h-12 rounded-xl flex items-center justify-center"
              :class="perm.type === 'auto_reset' ? 'bg-blue-100 text-blue-600' : 'bg-emerald-100 text-emerald-600'"
            >
              <component :is="renderIcon(perm.icon, 24)" />
            </div>
            <div>
              <h3 class="font-semibold text-gray-800">{{ perm.name }}</h3>
              <p class="text-xs text-gray-400">{{ perm.id }}</p>
            </div>
          </div>
          <Badge :type="perm.type">{{ perm.type === 'auto_reset' ? 'Auto Reset' : 'Top Up' }}</Badge>
        </div>
        <div class="mt-4 pt-4 border-t border-gray-100 grid grid-cols-2 gap-3 text-sm">
          <div><p class="text-gray-400 text-xs">Value</p><p class="font-medium">฿{{ perm.value }}</p></div>
          <div><p class="text-gray-400 text-xs">Frequency</p><p class="font-medium">{{ perm.frequency }}</p></div>
          <div><p class="text-gray-400 text-xs">Limit</p><p class="font-medium">{{ perm.usageLimit ?? 'Unlimited' }}</p></div>
          <div><p class="text-gray-400 text-xs">Fund Types</p><p class="font-medium">{{ perm.fundTypes.length }}</p></div>
        </div>
        <div class="mt-4 flex gap-2">
          <button @click="openPermModal(perm)" class="flex-1 px-3 py-2 text-sm bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors flex items-center justify-center gap-1">
            <Edit :size="14" /> Edit
          </button>
          <button @click="promptDelete(perm.id, 'Delete Permission', `Are you sure you want to delete &quot;${perm.name}&quot;?`)" class="px-3 py-2 text-sm bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors">
            <Trash2 :size="14" />
          </button>
        </div>
      </div>
    </div>

    <!-- Permission Modal -->
    <Modal
      :is-open="isPermModalOpen"
      @close="isPermModalOpen = false"
      :title="editingPerm ? 'Edit Permission' : 'Create Permission'"
      size="lg"
    >
      <form id="permForm" @submit.prevent="handleSavePermission" class="space-y-6">
        <div>
          <label class="text-xs font-bold text-gray-500 uppercase">Permission Name</label>
          <input name="name" :value="editingPerm?.name" required class="w-full mt-1 p-2.5 border border-gray-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500" />
        </div>
        <div>
          <label class="text-xs font-bold text-gray-500 uppercase">Type</label>
          <div class="flex gap-2 mt-1">
            <button type="button" @click="permFormType = 'auto_reset'" class="flex-1 p-3 rounded-lg border-2 transition-all" :class="permFormType === 'auto_reset' ? 'border-blue-500 bg-blue-50' : 'border-gray-200'">
              <Coffee class="mx-auto mb-1" /><span class="text-sm">Auto Reset</span>
            </button>
            <button type="button" @click="permFormType = 'top_up'" class="flex-1 p-3 rounded-lg border-2 transition-all" :class="permFormType === 'top_up' ? 'border-emerald-500 bg-emerald-50' : 'border-gray-200'">
              <DollarSign class="mx-auto mb-1" /><span class="text-sm">Top Up</span>
            </button>
          </div>
        </div>
        
        <template v-if="permFormType === 'auto_reset'">
          <div class="grid grid-cols-2 gap-4">
            <div><label class="text-xs font-bold text-gray-500 uppercase">Value (฿)</label><input name="value" type="number" :value="editingPerm?.value || 100" class="w-full mt-1 p-2.5 border border-gray-200 rounded-lg text-sm" /></div>
            <div><label class="text-xs font-bold text-gray-500 uppercase">Usage Limit</label><input name="usageLimit" type="number" :value="editingPerm?.usageLimit || 1" class="w-full mt-1 p-2.5 border border-gray-200 rounded-lg text-sm" /></div>
          </div>
          <div>
            <label class="text-xs font-bold text-gray-500 uppercase">Frequency</label>
            <select v-model="selectedFrequency" class="w-full mt-1 p-2.5 border border-gray-200 rounded-lg text-sm">
              <option value="Daily">Daily</option>
              <option value="Weekly">Weekly</option>
              <option value="Monthly">Monthly</option>
              <option value="Recurring">Recurring (Custom)</option>
            </select>
          </div>
          <div v-if="selectedFrequency === 'Recurring'" class="p-4 bg-gray-50 rounded-lg">
            <p class="text-xs text-gray-500 mb-3">Select active days for each week:</p>
            <div class="space-y-2">
              <div v-for="week in [1, 2, 3, 4, 5]" :key="week" class="flex items-center gap-2">
                <span class="w-16 text-xs text-gray-400">Week {{ week }}</span>
                <div class="flex gap-1">
                  <button
                    v-for="day in WEEK_DAYS"
                    :key="day.id"
                    type="button"
                    @click="handleGridToggle(week, day.id)"
                    class="w-8 h-8 rounded text-xs font-medium transition-colors"
                    :class="(recurringWeeks[week] || []).includes(day.id) ? 'bg-blue-500 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-100'"
                  >
                    {{ day.label }}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </template>

        <div v-if="permFormType === 'top_up'">
          <label class="text-xs font-bold text-gray-500 uppercase">Fund Types</label>
          <div class="flex flex-wrap gap-2 mt-2">
            <button
              v-for="ft in ['Employee Fill', 'Admin Fill']"
              :key="ft"
              type="button"
              @click="handleFundTypeToggle(ft)"
              class="px-3 py-2 rounded-lg text-sm border transition-all"
              :class="selectedFundTypes.includes(ft) ? 'bg-emerald-500 text-white border-emerald-500' : 'bg-white border-gray-200'"
            >
              {{ ft }}
            </button>
          </div>
        </div>
      </form>
      <template #footer>
        <button type="button" @click="isPermModalOpen = false" class="px-4 py-2 border border-gray-200 rounded-lg text-sm hover:bg-gray-50">Cancel</button>
        <button type="submit" form="permForm" class="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-700">Save</button>
      </template>
    </Modal>

    <!-- Delete Confirmation Modal -->
    <Modal :is-open="deleteModal.isOpen" @close="deleteModal.isOpen = false" :title="deleteModal.title">
      <p class="text-gray-600">{{ deleteModal.message }}</p>
      <template #footer>
        <button @click="deleteModal.isOpen = false" class="px-4 py-2 border border-gray-200 rounded-lg text-sm hover:bg-gray-50">Cancel</button>
        <button @click="confirmDelete" class="px-4 py-2 bg-red-600 text-white rounded-lg text-sm hover:bg-red-700">Delete</button>
      </template>
    </Modal>
  </div>
</template>
