<script setup>
import { ref } from 'vue';
import { Edit } from 'lucide-vue-next';
import Modal from '../components/ui/Modal.vue';
import { useApp } from '../composables/useApp';

const { 
  branchEmployees, branchGroups, 
  permissions, branchConfig, addLog 
} = useApp();

const isEmployeeModalOpen = ref(false);
const editingEmployee = ref(null);

const calculateInheritedWallets = (employeeGroups) => {
  const wallets = {};
  employeeGroups.forEach(groupId => {
    const group = branchGroups.value.find(g => g.id === groupId);
    if (group) {
      group.rules.forEach(rule => {
        const p = permissions.value.find(x => x.id === rule.permId);
        if (p && branchConfig.value[rule.permId]?.enabled) {
          wallets[rule.permId] = p;
        }
      });
    }
  });
  return Object.values(wallets);
};

const handleSaveEmployee = (e) => {
  const formData = new FormData(e.target);
  const groups = branchGroups.value
    .filter(g => formData.get(`group_${g.id}`))
    .map(g => g.id);
  
  const index = branchEmployees.value.findIndex(emp => emp.id === editingEmployee.value.id);
  if (index !== -1) {
    branchEmployees.value[index] = { ...branchEmployees.value[index], groups };
  }
  
  addLog('Employee Update', `Updated employee groups for ${editingEmployee.value.name}`);
  isEmployeeModalOpen.value = false;
};

const openModal = (emp) => {
  editingEmployee.value = emp;
  isEmployeeModalOpen.value = true;
};
</script>

<template>
  <div class="space-y-6">
    <h2 class="text-2xl font-bold text-gray-800">Employees</h2>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <table class="w-full">
        <thead class="bg-gray-50 border-b border-gray-100">
          <tr>
            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Employee</th>
            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Position</th>
            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Groups</th>
            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Inherited Wallets</th>
            <th class="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">Actions</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-50">
          <tr v-for="emp in branchEmployees" :key="emp.id" class="hover:bg-gray-50/50">
            <td class="px-4 py-3">
              <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center text-white font-bold">
                  {{ emp.name.charAt(0) }}
                </div>
                <div>
                  <p class="font-medium text-gray-800">{{ emp.name }}</p>
                  <p class="text-xs text-gray-400">{{ emp.id }}</p>
                </div>
              </div>
            </td>
            <td class="px-4 py-3 text-sm text-gray-600">{{ emp.position }}</td>
            <td class="px-4 py-3">
              <div class="flex flex-wrap gap-1">
                <template v-if="emp.groups.length > 0">
                  <span 
                    v-for="gId in emp.groups" 
                    :key="gId"
                    class="px-2 py-0.5 bg-purple-50 text-purple-700 rounded text-xs"
                  >
                    {{ branchGroups.find(x => x.id === gId)?.name }}
                  </span>
                </template>
                <span v-else class="text-gray-400 text-sm">No groups</span>
              </div>
            </td>
            <td class="px-4 py-3">
              <div class="flex flex-wrap gap-1">
                <template v-if="calculateInheritedWallets(emp.groups).length > 0">
                  <span 
                    v-for="w in calculateInheritedWallets(emp.groups)" 
                    :key="w.id"
                    class="px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded text-xs"
                  >
                    {{ w.name.split(' ')[0] }}
                  </span>
                </template>
                <span v-else class="text-gray-400 text-sm">None</span>
              </div>
            </td>
            <td class="px-4 py-3 text-right">
              <button @click="openModal(emp)" class="p-2 hover:bg-gray-100 rounded-lg">
                <Edit :size="16" />
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Edit Employee Modal -->
    <Modal :is-open="isEmployeeModalOpen" @close="isEmployeeModalOpen = false" :title="`Edit Employee: ${editingEmployee?.name}`">
      <form id="empForm" @submit.prevent="handleSaveEmployee" class="space-y-4">
        <div>
          <label class="text-xs font-bold text-gray-500 uppercase mb-2 block">Assign to Groups</label>
          <div class="space-y-2">
            <label v-for="group in branchGroups" :key="group.id" class="flex items-center gap-3 p-3 border border-gray-100 rounded-lg cursor-pointer hover:bg-gray-50">
              <input type="checkbox" :name="`group_${group.id}`" :checked="editingEmployee?.groups.includes(group.id)" class="rounded" />
              <span class="text-sm">{{ group.name }}</span>
            </label>
          </div>
        </div>
      </form>
      <template #footer>
        <button type="button" @click="isEmployeeModalOpen = false" class="px-4 py-2 border border-gray-200 rounded-lg text-sm hover:bg-gray-50">Cancel</button>
        <button type="submit" form="empForm" class="px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm hover:bg-emerald-700">Save</button>
      </template>
    </Modal>
  </div>
</template>
