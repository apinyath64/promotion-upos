<script setup>
import { computed } from 'vue';
import { ToggleRight, ToggleLeft } from 'lucide-vue-next';
import Badge from '../components/ui/Badge.vue';
import { useApp } from '../composables/useApp';
import { renderIcon } from '../utils/iconUtils';

const { 
  permissions, branchConfig, getActiveBranchPerms 
} = useApp();

const activeBranchPermIds = computed(() => getActiveBranchPerms());

const toggleBranchConfig = (permId) => {
  if (!branchConfig.value[permId]) {
    branchConfig.value[permId] = { enabled: false, validFrom: '', validTo: '' };
  }
  branchConfig.value[permId].enabled = !branchConfig.value[permId].enabled;
};

const updateBranchConfigDate = (permId, field, value) => {
  if (!branchConfig.value[permId]) {
    branchConfig.value[permId] = { enabled: false, validFrom: '', validTo: '' };
  }
  branchConfig.value[permId][field] = value;
};
</script>

<template>
  <div class="space-y-6">
    <h2 class="text-2xl font-bold text-gray-800">Wallet Configuration</h2>
    <p class="text-gray-500">Configure which wallets are active for this branch.</p>
    
    <div class="space-y-4">
      <div v-for="pid in activeBranchPermIds" :key="pid">
        <div v-if="permissions.find(p => p.id === pid)" class="bg-white rounded-xl p-5 border border-gray-100 shadow-sm">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-3">
              <div 
                class="w-10 h-10 rounded-lg flex items-center justify-center"
                :class="branchConfig[pid]?.enabled ? 'bg-emerald-100 text-emerald-600' : 'bg-gray-100 text-gray-400'"
              >
                <component :is="renderIcon(permissions.find(p => p.id === pid).icon)" />
              </div>
              <div>
                <h3 class="font-semibold text-gray-800">{{ permissions.find(p => p.id === pid).name }}</h3>
                <Badge :type="permissions.find(p => p.id === pid).type">
                  {{ permissions.find(p => p.id === pid).type === 'auto_reset' ? 'Auto Reset' : 'Top Up' }}
                </Badge>
              </div>
            </div>
            <button @click="toggleBranchConfig(pid)">
              <ToggleRight v-if="branchConfig[pid]?.enabled" class="text-emerald-500" :size="32" />
              <ToggleLeft v-else class="text-gray-400" :size="32" />
            </button>
          </div>
          
          <div v-if="branchConfig[pid]?.enabled" class="mt-4 pt-4 border-t border-gray-100 flex gap-4">
            <div class="flex-1">
              <label class="text-xs text-gray-500">Valid From</label>
              <input 
                type="date" 
                :value="branchConfig[pid]?.validFrom" 
                @input="e => updateBranchConfigDate(pid, 'validFrom', e.target.value)" 
                class="w-full mt-1 p-2 border border-gray-200 rounded-lg text-sm" 
              />
            </div>
            <div class="flex-1">
              <label class="text-xs text-gray-500">Valid To</label>
              <input 
                type="date" 
                :value="branchConfig[pid]?.validTo" 
                @input="e => updateBranchConfigDate(pid, 'validTo', e.target.value)" 
                class="w-full mt-1 p-2 border border-gray-200 rounded-lg text-sm" 
              />
            </div>
          </div>
        </div>
      </div>
      
      <div v-if="activeBranchPermIds.length === 0" class="text-center py-12 text-gray-400">
        No permissions assigned to this branch.
      </div>
    </div>
  </div>
</template>
