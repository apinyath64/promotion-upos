<script setup>
import { 
  Building2, Shield, History, Wallet, Users, UserCircle, LogOut, ChevronRight 
} from 'lucide-vue-next';
import { useApp } from '../../composables/useApp';

// Consuming context
const { 
  userRole, setUserRole, 
  currentView, setCurrentView, 
  managingBranch, setManagingBranch 
} = useApp();

const toggleRole = () => {
  setUserRole(userRole.value === 'System Admin' ? 'Branch Admin' : 'System Admin');
};

const NAV_ITEMS = {
  'System Admin': [
    { id: 'branches', label: 'Branch Management', icon: Building2 },
    { id: 'master', label: 'Master Permissions', icon: Shield },
    { id: 'audit', label: 'Audit Logs', icon: History },
  ],
  'Branch Admin': [
    { id: 'b_config', label: 'Wallet Configuration', icon: Wallet },
    { id: 'b_groups', label: 'Employee Groups', icon: Users },
    { id: 'b_employees', label: 'Employees', icon: UserCircle },
  ]
};
</script>

<template>
  <div class="w-64 bg-slate-900 h-screen flex flex-col text-white transition-all duration-300 shadow-xl">
    <!-- Header -->
    <div class="p-6 border-b border-slate-800">
      <div class="flex items-center gap-3 mb-1">
        <div class="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-lg shadow-lg shadow-blue-900/50">E</div>
        <h1 class="text-xl font-bold tracking-tight">Enterprise</h1>
      </div>
      <p class="text-xs text-slate-400 pl-11">Management System</p>
    </div>

    <!-- Managing Context Banner -->
    <div v-if="managingBranch" class="px-6 py-4 bg-slate-800/50 border-b border-slate-800">
      <p class="text-[10px] uppercase font-bold text-slate-400 mb-1">Managing Branch</p>
      <div class="flex items-center justify-between group cursor-pointer">
        <p class="font-medium text-sm text-blue-400 truncate">{{ managingBranch.name }}</p>
        <button 
          v-if="userRole === 'System Admin'" 
          @click="setManagingBranch(null); setCurrentView('branches')"
          class="text-slate-500 hover:text-white transition-colors"
          title="Exit Branch View"
        >
          <LogOut :size="14" />
        </button>
      </div>
    </div>

    <!-- Navigation -->
    <nav class="flex-1 p-4 space-y-2 overflow-y-auto">
      <p class="px-4 text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2">
        {{ userRole === 'System Admin' && managingBranch ? 'Branch Menu' : 'Main Menu' }}
      </p>
      
      <button 
        v-for="item in NAV_ITEMS[managingBranch && userRole === 'System Admin' ? 'Branch Admin' : userRole]" 
        :key="item.id"
        @click="setCurrentView(item.id)"
        class="w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all duration-200 group"
        :class="currentView === item.id ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20' : 'text-slate-400 hover:bg-slate-800 hover:text-white'"
      >
        <div class="flex items-center gap-3">
          <component :is="item.icon" :size="20" :class="currentView === item.id ? 'text-white' : 'text-slate-500 group-hover:text-white'" />
          <span class="text-sm font-medium">{{ item.label }}</span>
        </div>
        <ChevronRight v-if="currentView === item.id" :size="16" class="opacity-50" />
      </button>
    </nav>

    <!-- User Profile / Role Switcher -->
    <div class="p-4 border-t border-slate-800 bg-slate-950/30">
      <button 
        @click="toggleRole"
        class="w-full bg-slate-800 hover:bg-slate-700 text-slate-300 p-3 rounded-xl flex items-center justify-between transition-colors border border-slate-700/50 group"
      >
        <div class="flex items-center gap-3">
          <div class="w-8 h-8 rounded-full bg-gradient-to-tr from-slate-600 to-slate-500 flex items-center justify-center">
            <UserCircle :size="18" class="text-white" />
          </div>
          <div class="text-left">
            <p class="text-xs font-medium text-white group-hover:text-blue-200">{{ userRole }}</p>
            <p class="text-[10px] text-slate-500">Tap to switch</p>
          </div>
        </div>
      </button>
    </div>
  </div>
</template>
