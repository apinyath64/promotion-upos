<script setup>
import { X } from 'lucide-vue-next';

defineProps({
  isOpen: Boolean,
  title: String,
  size: {
    type: String,
    default: 'md'
  }
})

defineEmits(['close'])

const SIZE_CLASSES = {
  sm: 'max-w-sm',
  md: 'max-w-md',
  lg: 'max-w-lg',
  xl: 'max-w-xl',
  '2xl': 'max-w-2xl'
}
</script>

<template>
  <div v-if="isOpen" class="fixed inset-0 z-50 flex items-center justify-center p-4">
    <!-- Overlay -->
    <div @click="$emit('close')" class="absolute inset-0 bg-black/40 backdrop-blur-sm transition-opacity"></div>
    
    <!-- Modal Content -->
    <div 
      class="relative bg-white rounded-2xl shadow-xl w-full max-h-[90vh] flex flex-col transition-all overflow-hidden"
      :class="SIZE_CLASSES[size]"
    >
      <!-- Header -->
      <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
        <h3 class="text-lg font-bold text-gray-800">{{ title }}</h3>
        <button 
          @click="$emit('close')"
          class="p-1 hover:bg-gray-200 rounded-full transition-colors text-gray-500 hover:text-gray-700"
        >
          <X :size="20" />
        </button>
      </div>
      
      <!-- Body -->
      <div class="px-6 py-6 overflow-y-auto">
        <slot />
      </div>
      
      <!-- Footer -->
      <div v-if="$slots.footer" class="px-6 py-4 border-t border-gray-100 bg-gray-50 flex justify-end gap-3">
        <slot name="footer" />
      </div>
    </div>
  </div>
</template>
