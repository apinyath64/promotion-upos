import { reactive, provide, inject, toRefs } from 'vue';
import {
    INITIAL_BRANCHES,
    INITIAL_PERMISSIONS,
    INITIAL_LOGS,
    INITIAL_BRANCH_CONFIG,
    INITIAL_BRANCH_GROUPS,
    INITIAL_BRANCH_EMPLOYEES
} from '../data/mockData';

const APP_SYMBOL = Symbol('APP_CONTEXT');

export function provideApp() {
    const state = reactive({
        userRole: 'System Admin', // 'System Admin' | 'Branch Admin'
        currentView: 'branches',
        managingBranch: null,

        // Data
        branches: INITIAL_BRANCHES,
        permissions: INITIAL_PERMISSIONS,
        logs: INITIAL_LOGS,
        branchConfig: INITIAL_BRANCH_CONFIG,
        branchGroups: INITIAL_BRANCH_GROUPS,
        branchEmployees: INITIAL_BRANCH_EMPLOYEES
    });

    // Actions
    const setUserRole = (role) => {
        state.userRole = role;
        if (role === 'System Admin') {
            state.currentView = 'branches';
            state.managingBranch = null;
        } else {
            // Simulate logging in as Branch Admin for B001
            state.currentView = 'b_config';
            state.managingBranch = state.branches[0];
        }
    };

    const setManagingBranch = (branch) => {
        state.managingBranch = branch;
    };

    const setCurrentView = (view) => {
        state.currentView = view;
    };

    const addLog = (action, details) => {
        const newLog = {
            id: Date.now(),
            admin: state.userRole,
            action,
            details,
            timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19)
        };
        state.logs = [newLog, ...state.logs];
    };

    // Branch Admin Specific Helpers
    const getActiveBranchPerms = () => {
        if (!state.managingBranch) return [];
        // Ensure we are working with the latest state of the branch from the branches array
        const currentBranch = state.branches.find(b => b.id === state.managingBranch.id);
        return currentBranch ? currentBranch.permissions : [];
    };

    // Provide state and actions
    const context = {
        ...toRefs(state),
        setUserRole,
        setManagingBranch,
        setCurrentView,
        addLog,
        getActiveBranchPerms
    };

    provide(APP_SYMBOL, context);

    return context;
}

export function useApp() {
    const context = inject(APP_SYMBOL);
    if (!context) {
        throw new Error('useApp must be used within provideApp');
    }
    return context;
}
