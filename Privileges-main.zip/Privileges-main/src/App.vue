<script setup>
import { provideApp } from './composables/useApp';
import Sidebar from './components/layout/Sidebar.vue';

// Page imports
import BranchManagement from './pages/BranchManagement.vue';
import MasterPermissions from './pages/MasterPermissions.vue';
import AuditLogs from './pages/AuditLogs.vue';
import WalletConfiguration from './pages/WalletConfiguration.vue';
import EmployeeGroups from './pages/EmployeeGroups.vue';
import Employees from './pages/Employees.vue';

// Provide global state and destructure for local usage
const { currentView } = provideApp();
</script>

<template>
  <div class="flex h-screen bg-slate-100">
    <Sidebar />
    <main class="flex-1 overflow-auto p-8">
      <BranchManagement v-if="currentView === 'branches'" />
      <MasterPermissions v-if="currentView === 'master'" />
      <AuditLogs v-if="currentView === 'audit'" />
      <WalletConfiguration v-if="currentView === 'b_config'" />
      <EmployeeGroups v-if="currentView === 'b_groups'" />
      <Employees v-if="currentView === 'b_employees'" />
    </main>
  </div>
</template>
